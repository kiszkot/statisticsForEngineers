alpha = 1
beta = 1/24
sigma = 24
p = 1 - pgamma(60,alpha,scale=sigma)
print(p)