x = dbinom(2:5,5,0.2)
p = sum(x)
print(p)